/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gestionescolar1;

/**
 *
 * @author Gilberto Alexander Ventura Hernández
 *         Miguel Angel Vides Deras
 */
public interface Comparador {
    boolean igualQue(Object r);
    
    boolean menorQue(Object r);
    
    boolean menorIgual(Object r);
    
    boolean mayorQue(Object r);
    
    boolean mayorIgual(Object r);
}
